For platform builder(PB) installation, please copy the content of PB folder to your platform builder by yourself.

CE driver manager:
    NPTcfg.exe
    dsci_wce_x86.dll
    
For Windows CE5 Driver, add following files:
    CE5\CE5_Nptpdd.dll
    CE5\CE5_NPortINIT.dll

For Windows CE6 Driver, add following files:
    CE6\CE6_Nptpdd.dll
    CE6\CE6_NPortINIT.dll    